# v0.7.3 — 재검수 V26·V27 수정본과 반증

- `ai-office-v0.7.3.zip` — 수정본. `npm test` 82/82 (Node 22.22.0). 새 테스트 V26·V27 이 `test/v071-audit.test.mjs` 끝에.
- `new-defects-v073.mjs` — 검수자의 `new-defects.mjs` 를 세 군데만 바꾼 것: ① 이쪽 실행 환경에 IPv6 가 없어 `::` 대신 `127.0.0.1` 바인딩, ② 시작 거부되는 설정을 오류 대신 결과로 보고, ③ 제거된 `parseCidr/inCidr` 대신 제품 모듈 `src/trusted.mjs` 의 `buildTrusted().check()` 를 그대로 호출. IPv6 가 있는 환경에서는 원본 스크립트의 바인딩을 그대로 쓰면 됩니다 (`::` 에서 127.0.0.1 접속 → peer `::ffff:127.0.0.1` 도 테스트 V27 에 포함).
- `results-v073.jsonl` — 결과.

| 케이스 | v0.7.2 | v0.7.3 |
| --- | --- | --- |
| V26_invalid_mask (`/33`) | 200 + Secure 쿠키 (전체 신뢰) | 시작 거부: "prefix 는 0~32" |
| V26_empty_mask (`192.0.2.0/`) | 200 + Secure 쿠키 (/0 으로 해석) | 시작 거부: "IP 아님" |
| V26_valid_untrusted_control | 403 | 403 (변화 없음, 정상) |
| V27_exact_mapped_peer (`::ffff:127.0.0.1`) | 403 | 200 + Secure |
| V27_native_comparison ×3 | false/false/true (내장과 불일치) | true/true/false (내장과 일치) |

설정 문법: `IP` 또는 `IP/prefix`, 콤마 구분. `/0` 은 명시했을 때만 허용. 비우면 모든 peer 신뢰(프록시가 직접 노출을 막는 플랫폼에서만).
