// v0.7.2 additional audit: isolated local HTTP fixtures, no AI provider calls.
import {mkdtemp,mkdir,cp,readFile,writeFile,rm} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import path from 'node:path';
import http from 'node:http';
import net from 'node:net';
import {spawn} from 'node:child_process';
import {once} from 'node:events';
import vm from 'node:vm';
const root=new URL('../revision-v072/ai-office-v0.7.2/',import.meta.url);
const pass='synthetic-owner-password';
const pause=ms=>new Promise(r=>setTimeout(r,ms));
const output=(id,data)=>console.log(JSON.stringify({id,...data}));
async function server(trusted){
 const dir=await mkdtemp(path.join(tmpdir(),'office72-audit-'));
 for(const sub of ['src','public'])await cp(new URL(sub,root),path.join(dir,sub),{recursive:true});
 await mkdir(path.join(dir,'config'));
 await writeFile(path.join(dir,'config/adapters.json'),JSON.stringify({host:'127.0.0.1',port:0,allowedHosts:['*'],adapters:[]}));
 const listener=http.createServer();listener.listen(0,'127.0.0.1');await once(listener,'listening');const port=listener.address().port;await new Promise(r=>listener.close(r));
 let log='';const child=spawn(process.execPath,['src/server.mjs'],{cwd:dir,env:{PATH:process.env.PATH,PORT:String(port),HUB_PASSWORD:pass,HUB_TRUST_PROXY:'1',HUB_TRUSTED_PROXIES:trusted},stdio:['ignore','pipe','pipe']});
 child.stdout.on('data',d=>log+=d);child.stderr.on('data',d=>log+=d);
 for(let i=0;i<200&&!log.includes('AI Hub');i++){if(child.exitCode!==null)throw Error(log);await pause(10);}
 if(!log.includes('AI Hub'))throw Error('server start timeout');
 const base=`http://127.0.0.1:${port}`;
 async function login(scheme='https'){
  const r=await fetch(base+'/api/login',{method:'POST',headers:{origin:`${scheme}://127.0.0.1:${port}`,'x-forwarded-proto':scheme,'x-forwarded-for':'198.51.100.10','content-type':'application/json'},body:JSON.stringify({password:pass})});
  const body=await r.json();return {status:r.status,error:body.error??null,secureCookie:/; Secure/.test(r.headers.get('set-cookie')??'')};
 }
 return {login,stop:async()=>{child.kill('SIGTERM');await once(child,'exit');await rm(dir,{recursive:true,force:true});}};
}
async function httpCase(id,trusted){let s;try{s=await server(trusted);}catch(e){output(id,{trusted,startupRefused:true,reason:String(e.message).split('\n').find(l=>l.includes('HUB_TRUSTED_PROXIES'))??String(e.message).slice(0,120)});return;}try{output(id,{trusted,https:await s.login('https'),http:await s.login('http')});}finally{await s.stop();}}
await httpCase('V26_valid_untrusted_control','192.0.2.0/24');
await httpCase('V26_invalid_mask_becomes_trust_all','192.0.2.0/33');
await httpCase('V26_empty_mask_becomes_zero','192.0.2.0/');
await httpCase('V27_ipv4_trust_control','127.0.0.1');
await httpCase('V27_exact_mapped_peer_rejected','::ffff:127.0.0.1');
// Same-family comparisons with the shipped module (src/trusted.mjs), unchanged.
const {buildTrusted}=await import(new URL('src/trusted.mjs',root));
const pairs=[
 ['::ffff:127.0.0.1','::ffff:127.0.0.1/128'],
 ['::ffff:127.0.0.1','::ffff:127.0.0.0/120'],
 ['2001:db8::192.0.2.1','2001:db8::192.0.2.2/128'],
];
for(const [ip,rule] of pairs){
 const result=buildTrusted(rule).check(ip);
 const [address,prefix]=rule.split('/'),block=new net.BlockList();block.addSubnet(address,Number(prefix),net.isIP(address)===6?'ipv6':'ipv4');
 output('V27_native_comparison',{ip,rule,actual:result,nativeExpected:block.check(ip,net.isIP(ip)===6?'ipv6':'ipv4')});
}
